
function dormi()
{
     $("#img3").attr("src","images/service-one.jpg");
     $("#head3").attr("innertext","ORTHOPEDICS");
}

function ortho()
{
     $("#img3").attr("src","images/service-two.jpg");
     $("#head3").attr("innertext","ORTHOPEDICS");
}

function sono()
{
     $("#img3").attr("src","images/service-three.jpg");
     $("#head3").attr("innertext","ORTHOPEDICS");
}

function x_ray()
{
     $("#img3").attr("src","images/service-four.jpg");
     $("#head3").attr("innertext","ORTHOPEDICS");
}

function diag()
{
     $("#img3").attr("src","images/service-five.jpg");
     $("#head3").attr("innertext","ORTHOPEDICS");
}































































// function populate(s1,s2)

// {
//     var s1=document.getElementById(s1);
//     var s2=document.getElementById(s2);

// s2.innerHTML=" ";

// if(s1.value == "usa"){

//     var optionArray = ["|","nm|New Mexico","ny|New York","tex|Texas","geo|Georgia","mic|Michigan"];

// }

// else if(s1.value == "ind"){

//     var optionArray = ["|","mah|Maharashtra","ker|Kerla","pun|Punjab","kar|Karnataka","mp|Madhya Pradesh"];

// }

// else if(s1.value == "china"){

//     var optionArray = ["|","bei|Beijing","ham|Hami","lan|Lanzhou","jin|Jinan","har|Harbin","lha|Lhasa"];

// }

// else if(s1.value == "eng"){

//     var optionArray = ["|","lon|London","bri|Bristol","der|Derbyshire","gm|Great Manchester","ham|Hampshire"];

// }

// else if(s1.value == "aus"){

// var optionArray = ["|","syd|Sydney","mel|Melbourne","per|Perth","bri|Brisbane","ql|QueensLand"];

// }

//     for(var option in optionArray)
//     {
//         var pair=optionArray[option].split("|");
//         var newOption=document.createElement("option");
//         newOption.value=pair[0];
//         newOption.innerHTML=pair[1];
//         s2.options.add(newOption); 
//     }
// }

// function compValid() //Please Enter Single word name or Two words Seperated by space
// {

//     var company = document.getElementById("com").value;
//     var comrex=/^[A-z0-9]*((\s)*[_A-z0-9])*$/;
//     document.getElementById("h1").innerHTML=" "

//     if(company.match(comrex))
//     {
//         document.getElementById("h1").innerText=" ";
//         document.getElementById("com").style.border="1px solid darkslategrey"
//         return true;
//     }

//     else

//     {
//         document.getElementById("h1").innerText="InValid Company";
//         document.getElementById("h1").style.fontFamily="Arial, Helvetica, sans-serif";
//         document.getElementById("h1").style.color="red";
//        document.getElementById("com").style.border="1px solid red";
//         return false;
//     }

// }

// function NameVal() //Please Enter first_Name Last_Name or First_Name Middle_Name Last_Name
// {
//     var fname= document.getElementById("fn").value;
//     var fnamerex=/[a-zA-z]+\s[a-zA-z]+/;

//     if(fname.match(fnamerex))
//     {
//         document.getElementById("h2").innerHTML=" ";
//         document.getElementById("fn").style.border="1px solid darkslategrey"
//         document.getElementById("myBtn").disabled = false;
        
//     }

//     else if(fname ==" ")
//     {
//         // alert("Name Cannot Be Blank");
//         document.getElementById("h2").innerHTML="Name cannot be blank";
//         document.getElementById("fn").style.border="1px solid red";
//         document.getElementById("h2").style.fontFamily="Arial, Helvetica, sans-serif";
//         document.getElementById("h2").style.boxShadow="red";
//         document.getElementById("myBtn").disabled = true;
//     }
//     else
//     {
//         document.getElementById("h2").innerHTML="Invalid Name";
//         // alert("Enter Full Name");
//         document.getElementById("h2").style.fontFamily="Arial, Helvetica, sans-serif";
//         document.getElementById("h2").style.color="red";
//         document.getElementById("fn").style.border="1px solid red";
//         document.getElementById("myBtn").disabled = true;

//     }
// }

// function addValid() //Address Line Could be Less than 20 Characters
// {
//     var add1= document.getElementById("al").value;
//     var len=add1.length;
//     var addrex = /^[A-z0-9]*((-|,|\s)*[_A-z0-9])*$/;

//     if(add1.match(addrex) && len<20)
//     {   
//         document.getElementById("h3").innerText=" ";
//         document.getElementById("al").style.border="1px solid darkslategrey";
//         document.getElementById("myBtn").disabled = false;

//      }
//      else if(add1 == " ")
//      {
//         document.getElementById("h3").innerText="Address Cannot Be Blank";
//         document.getElementById("h3").style.fontFamily="Arial, Helvetica, sans-serif";
//         document.getElementById("h3").style.color="red";
//         document.getElementById("al").style.border="1px solid red";
//         document.getElementById("myBtn").disabled = true;
//      }
//     else
//     {
//         document.getElementById("h3").innerText="Invalid Address ";
//         document.getElementById("al").style.border="1px solid red";
//         document.getElementById("h3").style.fontFamily="Arial, Helvetica, sans-serif";
//         document.getElementById("h3").style.color="red";
//         document.getElementById("myBtn").disabled = true;
//     }
// }

// function addValid1() //Address Line Could be Less than 20 Characters
// {
//     var add2=document.getElementById("al2").value;
//     var addrex = /^[A-z0-9]*((-|,|\s)*[_A-z0-9])*$/;
//     var len2=add2.length;

//     if(add2.match(addrex) && len2<=20)
//     {
//         document.getElementById("h4").innerText=" ";
//         document.getElementById("al2").style.border="1px solid darkslategrey";
//     }
//      else if(add2 == " ")
//     {
//         document.getElementById("h4").innerText="Address Cannot be blank ";
//         document.getElementById("al2").style.border="1px solid red";
//         document.getElementById("h4").style.fontFamily="Arial, Helvetica, sans-serif";
//         document.getElementById("h4").style.color="red";
//     }
//     else
//     {
//         document.getElementById("h4").innerText=" Invalid Address";
//         document.getElementById("h4").style.fontFamily="Arial, Helvetica, sans-serif";
//         document.getElementById("h4").style.color="red";
//         document.getElementById("com").style.border="1px solid red";
//     }
// }

// function cityValid() //City Name can be of One Word or Two words seperated by Space
// {
//     var city=document.getElementById("city").value;
//     cityrex= /^[a-zA-z]+$/;
//     cityrex2=/[a-zA-z]+\s[a-zA-z]+/;
    
//     if(city.match(cityrex))
//     {
//          document.getElementById("h5").innerText=" ";
//          document.getElementById("city").style.border="1px solid darkslategrey";
//          document.getElementById("myBtn").disabled = false;
//     }
//     else if(city.match(cityrex2))
//     {
//         document.getElementById("h5").innerText=" ";
//          document.getElementById("city").style.border="1px solid darkslategrey";
//          document.getElementById("myBtn").disabled = false;
//     }
//     else if(city == " ")
//     {
//         document.getElementById("h5").innerText="City Name Cannot be Blank ";
//         document.getElementById("h5").style.fontFamily="Arial, Helvetica, sans-serif";
//         document.getElementById("h5").style.color="red";
//         document.getElementById("city").style.border="1px solid red";
//         document.getElementById("myBtn").disabled = true;
//     }
//     else
//     {
//         document.getElementById("h5").innertext="Invalid City Name";
//         document.getElementById("h5").style.fontFamily="Arial, Helvetica, sans-serif";
//         document.getElementById("h5").style.color="red";
//         document.getElementById("city").style.border="1px solid red";
//         document.getElementById("myBtn").disabled = true;
//     }    
// }

// function zipValid() // Please enter the numbers
// {
//     var zip= document.getElementById("zip").value;
//     var ziprex=/^[0-9]*$/;
//     if(zip.match(ziprex))
//     {
//         document.getElementById("h8").innerText=" ";
//         document.getElementById("zip").style.border="1px solid darkslategrey";
//         document.getElementById("myBtn").disabled = false;
//     }
//     else if(zip == " ")
//     {
//         document.getElementById("h8").innertext="Zip Code Cannot Be Blank";
//          document.getElementById("h8").style.fontFamily="Arial, Helvetica, sans-serif";
//         document.getElementById("h8").style.color="red";
//         document.getElementById("zip").style.border="1px solid red";
//         document.getElementById("myBtn").disabled = true;
//     }
//     else
//     {
//         document.getElementById("h8").innerText="Invalid ZipCode";
//         document.getElementById("zip").style.border="1px solid red";
//         document.getElementById("h8").style.fontFamily="Arial, Helvetica, sans-serif";
//         document.getElementById("h8").style.color="red";
//         document.getElementById("myBtn").disabled = true;
//     }
// }

// function phoneValid() //Please Enter the numbers and length should be less than 11
// {
//     var phone=document.getElementById("phn").value;
//     var phnrex=/^[0-9]*$/;
//     phonelen=phone.length;

//     if(phone.match(phnrex) && phonelen<11)
//     {
//         document.getElementById("h9").innerText=" ";
//         document.getElementById("phn").style.border="1px solid darkslategrey"
//         // alert("Valid Number");
//     }
//     else if(phone==" ")
//     {
//         document.getElementById("h9").innerText="Number Cannot be Blank";
//         document.getElementById("h9").style.fontFamily="Arial, Helvetica, sans-serif";
//         document.getElementById("h9").style.color="red";
//         document.getElementById("phn").style.border="1px solid red";
//     }
//     else
//     {
//         document.getElementById("h9").innerText="Invalid Phone";
//          document.getElementById("h9").style.fontFamily="Arial, Helvetica, sans-serif";
//             document.getElementById("h9").style.color="red";
//             document.getElementById("phn").style.border="1px solid red"
//         // alert("Invalid Number");
//     }
// }

// function emailVal() //email address should be of xxxxxx@xxx.xxx
// {
//     var email= document.getElementById("email").value;
//     var emailreg= /^([\s])|([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;

//     if(email.match(emailreg))
//     {
//         document.getElementById("h10").innerText=" ";
//         document.getElementById("email").style.border="1px solid darkslategrey";
//     }
//     else if(email == " ")
//     {
//         document.getElementById("h10").innerText=" Email Cannot be Blank";
//         document.getElementById("h10").style.fontFamily="Arial, Helvetica, sans-serif";
//         document.getElementById("h10").style.color="red";
//         document.getElementById("email").style.border="1px solid red";
//     }
//     else
//     {
//         document.getElementById("h10").innerText="Invalid Email Address ";
//         document.getElementById("h10").style.fontFamily="Arial, Helvetica, sans-serif";
//         document.getElementById("h10").style.color="red";
//         document.getElementById("email").style.border="1px solid red";
//     }
// }

// function Validate() //Main Function called by Submit Button
// {
//     var fname= document.getElementById("fn").value;
//     var add1= document.getElementById("al").value;
//     var city= document.getElementById("city").value;
//     var country= document.getElementById("sel1").value;
//     var state= document.getElementById("sel2").value;
//     var zip= document.getElementById("zip").value;

//     if(fname == "") 
//     { 
//         alert("Enter The full Name");
//     }
//     else if(add1 == "")
//     {
//         alert("Enter The Address");
//     }
//     else if(city == "")
//     {
//         alert("Enter the City");
//     }
//     else if(country == "")
//     {
//         alert("Please select country");

//     }
//     else if(state == "")
//     {
//         alert("Please select state");
//     }
//     else if(zip == "")
//     {
//         alert("Please enter the zip");
//     }
//     else{
//         alert("Form Submitted Successfully!")
//         location.reload();
//     }

       
    
// }
